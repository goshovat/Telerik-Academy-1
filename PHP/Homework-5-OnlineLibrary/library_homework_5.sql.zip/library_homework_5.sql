-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Време на генериране: 
-- Версия на сървъра: 5.5.32
-- Версия на PHP: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- БД: `library_homework_5`
--
CREATE DATABASE IF NOT EXISTS `library_homework_5` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library_homework_5`;

-- --------------------------------------------------------

--
-- Структура на таблица `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `author_id` int(11) NOT NULL AUTO_INCREMENT,
  `author_name` varchar(250) NOT NULL,
  PRIMARY KEY (`author_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Схема на данните от таблица `authors`
--

INSERT INTO `authors` (`author_id`, `author_name`) VALUES
(1, 'Caroline Stevermer'),
(2, 'Patricia C. Wrede'),
(3, 'Rachel Cohn'),
(4, 'David Leviathan'),
(5, 'John Green'),
(6, 'Terry Pratchett'),
(7, 'Neil Gaiman');

-- --------------------------------------------------------

--
-- Структура на таблица `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_title` varchar(250) NOT NULL,
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Схема на данните от таблица `books`
--

INSERT INTO `books` (`book_id`, `book_title`) VALUES
(1, 'Sorcery and Cecilia'),
(2, 'Nick and Norah’s Infinite Playlist'),
(3, 'Nick and Norah’s Infinite Playlist'),
(4, 'Will Grayson'),
(5, 'Good Omens'),
(6, 'Raising Steam'),
(7, 'American Gods'),
(8, 'Emergent'),
(9, 'The Far West');

-- --------------------------------------------------------

--
-- Структура на таблица `books_authors`
--

CREATE TABLE IF NOT EXISTS `books_authors` (
  `book_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  KEY `book_id` (`book_id`),
  KEY `author_id` (`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Схема на данните от таблица `books_authors`
--

INSERT INTO `books_authors` (`book_id`, `author_id`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(4, 4),
(4, 5),
(5, 6),
(5, 7),
(6, 6),
(7, 7),
(8, 3),
(9, 2);

-- --------------------------------------------------------

--
-- Структура на таблица `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `user_id` int(11) NOT NULL,
  `text` text NOT NULL,
  `date_time` datetime NOT NULL,
  `book_id` int(11) NOT NULL,
  KEY `user_id` (`user_id`,`book_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Схема на данните от таблица `comments`
--

INSERT INTO `comments` (`user_id`, `text`, `date_time`, `book_id`) VALUES
(2, 'Много добра книга! Препоръчвам я на всички.', '2013-10-23 17:48:43', 7),
(2, 'Доста зарибяваща е.', '2013-10-23 17:49:03', 7),
(2, 'Не ме изкефи много.', '2013-10-23 17:49:44', 9),
(2, 'Прекрасна книга.', '2013-10-23 17:50:01', 2),
(1, 'Ще я прегледам :)', '2013-10-23 17:50:43', 7),
(1, 'Дали си струва книгата?', '2013-10-23 17:55:24', 6),
(1, 'Някой да сподели, ако я е чел', '2013-10-23 17:55:36', 6),
(1, 'За какво става дума в тази книга?', '2013-10-23 17:56:01', 4),
(3, 'Интересно заглавие, мисля да я прочета. :P', '2013-10-23 17:57:11', 8),
(3, 'Тъкмо я приключих. Искам да изкажа най-големите си хвалби за тази книга. Няма друга като нея.', '2013-10-23 17:58:04', 5),
(3, 'Четете и не се чудете :)', '2013-10-23 17:58:42', 5),
(4, 'Да, много е добра !', '2013-10-23 17:59:45', 7),
(4, 'Ще си я взема значи.', '2013-10-23 18:00:14', 2),
(4, 'И на мен ми е интересно да разбера', '2013-10-23 18:00:52', 4),
(4, 'И мен :(', '2013-10-23 18:03:42', 9),
(3, 'И на мен ми достави голямо удоволствие докато я четях :)', '2013-10-23 18:10:29', 7);

-- --------------------------------------------------------

--
-- Структура на таблица `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(20) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Схема на данните от таблица `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password`) VALUES
(1, 'user1', '123456'),
(2, 'gosho', '123456'),
(3, 'ivancho', '123456'),
(4, 'Master', '123456');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
